return {
  {
    "elkowar/yuck.vim",
    ft = "yuck",
  },
}
